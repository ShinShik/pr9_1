class Komer_bell (var Company : String, Number : String, Date : String, Time : String, Postcode : String) :
    bell (Number, Date, Time, Postcode) {

    override fun Input() {
        println("Введите название помпании");Company = readln()
        println("Введите Номер телефона");Number = readln()
        println("Введите дату");Date = readln()
        println("Введите время");Time = readln()
        println("Введите код города");Postcode = readln()
    }
    override fun Print_info(){
        println("Звонок с номера ${Number} ($Date) происходил в $Time из города $Postcode\nКомпания $Company ")
    }
    open fun Init_among_us(){
        val x = Number[3].toInt()
        var y = ""
        when (x){
            1 -> y = "Мегафон"
            2 -> y = "МТС"
            3 -> y = "Билайн"
            4 -> y = "Йота"
            5 -> y = "Тинькофф"
            6 -> y = "Сбер"
            7 -> y = "Теле2"
            else -> y = "Мотив"
        }
        if (Company == y){
            println("Данный сотрудник хорош")
        }
        else {
            println("Данный сотрудник amogus")
        }
    }
}