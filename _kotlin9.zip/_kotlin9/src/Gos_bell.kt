class Gos_bell(var Code : Int, var Department : String, Number : String, Date : String, Time : String, Postcode : String) :
    bell (Number, Date, Time, Postcode) {

        open fun Inp_code(){
            println("Для получения информации следует ввести код")
            if (readln().toInt() == Code){
                Print_info()
                Print_oper()
            }
            else{println("Введён неверный код, данные не доступны")}
        }

    override fun Input() {
        println("Введите шифр");Code = readln().toInt()
        println("Введите отдел");Department = readln()
        println("Введите Номер телефона");Number = readln()
        println("Введите дату");Date = readln()
        println("Введите время");Time = readln()
        println("Введите код города");Postcode = readln()
    }
    override fun Print_info(){
            println("Звонок с номера $Number ($Date) происходил в $Time из города $Postcode\nОтдел $Department ($Code)")
    }
}