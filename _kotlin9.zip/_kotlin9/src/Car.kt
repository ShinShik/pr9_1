open class Car (var stamp : String, var power : Int, var price : Double) {

    open fun Input(){
        println("Введите марку"); stamp = readln()
        println("Введите мощность"); power = readln().toInt()
        println("Введите цену"); price = readln().toDouble()
    }
    open fun Print_info(){
        println("Марка $stamp мощностью $power ценой $price")
    }
    fun Nal(){
        when(power){
            in 1..59->println("Налог 60 руб")
            in 60..100-> println("Налог 100 руб")
            in 101..300-> println("Налог 200 руб")
            else -> println("Налог 0 руб")
        }
    }

}