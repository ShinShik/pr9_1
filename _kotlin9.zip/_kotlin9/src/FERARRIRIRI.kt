class FERARRIRIRI(stamp : String, power : Int, price : Double, var color : String, var model : String, var skor : Int)
    : Car(stamp,power,price){

    override fun Input(){
        stamp = "FERARIRIRI"
        println("Введите мощность"); power = readln().toInt()
        println("Введите цену"); price = readln().toDouble()
        println("Введите цвет"); color = readln()
        println("Введите модель"); model = readln()
        println("Введите за сколько будет разгоняться до 100км/ч"); skor = readln().toInt()
    }
    override fun Print_info(){
        println("Марка $stamp модель $model раскраской $$color мощностью $power ценой $price\nразгон до 100 за $skor секунд")
    }
    fun Set_price(){
        when(skor){
            in 1..5->price*=2
            in 6..10-> price*=1.5
            else->price=price
        }
    }
}