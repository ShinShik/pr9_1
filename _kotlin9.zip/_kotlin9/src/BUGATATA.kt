class BUGATATA(stamp : String, power : Int, price : Double, var color : String, var model : String)
    : Car(stamp,power,price){

    override fun Input(){
        stamp = "BAGATATA"
        println("Введите мощность"); power = readln().toInt()
        println("Введите цену"); price = readln().toDouble()
        println("Введите цвет"); color = readln()
        println("Введите модель"); model = readln()
    }
    override fun Print_info(){
        println("Марка $stamp модель $model раскраской $$color мощностью $power ценой $price")
    }
    fun Buy(){
        println("Введите количество имеющихся у вас денег")
        if (price <= readln().toDouble()) println("Вы можете себе купить данную модель")
        else {
            println("У вас недостаточно денег, возьмите кредит и возвращайтесь или продайте поч...")
        }
    }


}