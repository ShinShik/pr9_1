//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    try
    {
        var Bell = bell("89999999999", "01.01.2000", "00:00", "495")
        Bell.Input()
        Bell.Print_info()
        Bell.Print_oper()
    }
    catch (a: Exception) {
        println("ERROR")
    }
    try
    {
        val g_bell = Gos_bell(1, "Полиция", "89999999999", "01.01.2000", "00:00", "495")
        g_bell.Input()
        g_bell.Inp_code()
    }
    catch (a: Exception) {
        println("ERROR")
    }
    try
    {
        val k_bell = Komer_bell(" ", "89999999999", "01.01.2000", "00:00", "495")
        k_bell.Input()
        k_bell.Print_info()
        k_bell.Init_among_us()
    }
    catch (a: Exception) {
        println("ERROR")
    }
    try
    {
        var car = Car("",0,0.0)
        car.Input()
        car.Print_info()
        car.Nal()
    }
    catch (a: Exception) {
        println("ERROR")
    }
    try
    {
        var bag = BUGATATA("",0,0.0,"","")
        bag.Input()
        bag.Print_info()
        bag.Buy()
    }
    catch (a: Exception) {
        println("ERROR")
    }
    try
    {
        var fer = FERARRIRIRI("",0,0.0,"","",0)
        fer.Input()
        fer.Set_price()
        fer.Print_info()
    }
    catch (a: Exception) {
        println("ERROR")
    }
}