
open class bell (var Number : String, var Date : String, var Time : String, var Postcode : String){

    open fun Input() {
        println("Введите Номер телефона");Number = readln()
        println("Введите дату");Date = readln()
        println("Введите время");Time = readln()
        println("Введите код города");Postcode = readln()
    }
    open fun Print_info(){
        println("Звонок с номера $Number ($Date) происходил в $Time из города $Postcode")
    }
    open fun Print_oper(){
        val x = Number[2].toInt()
        when (x){
            1 -> println("Мегафон")
            2 -> println("МТС")
            3 -> println("Билайн")
            4 -> println("Йота")
            5 -> println("Тинькофф")
            6 -> println("Сбер")
            7 -> println("Теле2")
            else -> println("Мотив")
        }
    }
}